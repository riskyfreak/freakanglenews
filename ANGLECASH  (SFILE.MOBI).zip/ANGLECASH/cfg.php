<?php

//MASUKAN USER_ID MILIK KALIAN!!
$user_id = "xxxx";
